package swingJBS;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import dao.PtableDAO;
import dao.RideRDAO;
import dao.SmartRDAO;
import dto.PtableDTO;
import dto.RideRDTO;
import dto.SmartRDTO;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class RideChange {
	private static JTable table_1;
	private String sr_id;
	private JTextField t2;
	private JTextField t3;
	private JTextField t4;
	private JTextField t1;
	private JTextField t5;
	private JTextField t6;
	private JTextField t7;
	
	public RideChange(int x, int y, String rr_id) throws Exception {
		
		
				
		JFrame f = new JFrame();
		
		f.setSize(600, 600);
		f.setTitle("놀이기구 시간표 정보");
		f.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.GRAY);
		panel.setLayout(null);
		panel.setBounds(12, 59, 560, 492);
		f.getContentPane().add(panel);

		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBounds(12, 10, 536, 43);
		panel.add(panel_1);
		panel_1.setBackground(Color.LIGHT_GRAY);

		JLabel lblNewLabel = new JLabel(" 예약 정보를 확인 해주세요. ");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setLocation(12, 10);
		lblNewLabel.setSize(512, 22);
		lblNewLabel.setFont(new Font("굴림", Font.BOLD, 20));
		panel_1.add(lblNewLabel);

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setLayout(null);
		panel_2.setBounds(12, 10, 560, 39);
		f.getContentPane().add(panel_2);

		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBounds(12, 63, 536, 419);
		panel.add(panel_3);
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_3.setLayout(null);

		JButton b2 = new JButton("닫기");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		
		JButton b1 = new JButton("예약취소");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					int jop = JOptionPane.showConfirmDialog(null, "예약을 취소하시겠습니까?", "예약취소", 0, 3);
					if(jop==0) {
						
						f.dispose();
					}
					
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		b1.setFont(new Font("굴림", Font.BOLD, 14));
		b1.setBounds(135, 361, 129, 36);
		panel_3.add(b1);
		b2.setBounds(306, 361, 97, 36);
		panel_3.add(b2);

		b2.setFont(new Font("굴림", Font.BOLD, 14));
		
		JLabel l1 = new JLabel("예약번호 : ");
		l1.setHorizontalAlignment(SwingConstants.RIGHT);
		l1.setFont(new Font("굴림", Font.BOLD, 20));
		l1.setBounds(50, 10, 123, 28);
		panel_3.add(l1);
		
		JLabel l2 = new JLabel("예약자명 : ");
		l2.setHorizontalAlignment(SwingConstants.RIGHT);
		l2.setFont(new Font("굴림", Font.BOLD, 20));
		l2.setBounds(50, 61, 123, 28);
		panel_3.add(l2);
		
		JLabel l3 = new JLabel("놀이기구명 : ");
		l3.setHorizontalAlignment(SwingConstants.RIGHT);
		l3.setFont(new Font("굴림", Font.BOLD, 20));
		l3.setBounds(26, 113, 151, 28);
		panel_3.add(l3);
		
		JLabel l4 = new JLabel("이용날짜 : ");
		l4.setHorizontalAlignment(SwingConstants.RIGHT);
		l4.setFont(new Font("굴림", Font.BOLD, 20));
		l4.setBounds(50, 163, 123, 28);
		panel_3.add(l4);
		
		JLabel l5 = new JLabel("탑승시간 : ");
		l5.setHorizontalAlignment(SwingConstants.RIGHT);
		l5.setFont(new Font("굴림", Font.BOLD, 20));
		l5.setBounds(50, 215, 123, 28);
		panel_3.add(l5);
		
		JLabel l6 = new JLabel("시작시간 : ");
		l6.setHorizontalAlignment(SwingConstants.RIGHT);
		l6.setFont(new Font("굴림", Font.BOLD, 20));
		l6.setBounds(50, 266, 123, 28);
		panel_3.add(l6);
		
		JLabel l7 = new JLabel("종료시간 : ");
		l7.setHorizontalAlignment(SwingConstants.RIGHT);
		l7.setFont(new Font("굴림", Font.BOLD, 20));
		l7.setBounds(50, 318, 123, 28);
		panel_3.add(l7
				);
		
		t1 = new JTextField();
		t1.setFont(new Font("굴림", Font.BOLD, 20));
		t1.setEditable(false);
		t1.setColumns(10);
		t1.setBackground(Color.LIGHT_GRAY);
		t1.setBounds(185, 10, 286, 28);
		panel_3.add(t1);
		
		t2 = new JTextField();
		t2.setFont(new Font("굴림", Font.BOLD, 20));
		t2.setEditable(false);
		t2.setColumns(10);
		t2.setBackground(Color.LIGHT_GRAY);
		t2.setBounds(185, 61, 286, 28);
		panel_3.add(t2);
		
		t3 = new JTextField();
		t3.setFont(new Font("굴림", Font.BOLD, 20));
		t3.setEditable(false);
		t3.setColumns(10);
		t3.setBackground(Color.LIGHT_GRAY);
		t3.setBounds(185, 113, 286, 28);
		panel_3.add(t3);
		
		t4 = new JTextField();
		t4.setFont(new Font("굴림", Font.BOLD, 20));
		t4.setEditable(false);
		t4.setColumns(10);
		t4.setBackground(Color.LIGHT_GRAY);
		t4.setBounds(185, 165, 286, 28);
		panel_3.add(t4);
		
		t5 = new JTextField();
		t5.setFont(new Font("굴림", Font.BOLD, 20));
		t5.setEditable(false);
		t5.setColumns(10);
		t5.setBackground(Color.LIGHT_GRAY);
		t5.setBounds(185, 215, 286, 28);
		panel_3.add(t5);
		
		t6 = new JTextField();
		t6.setFont(new Font("굴림", Font.BOLD, 20));
		t6.setEditable(false);
		t6.setColumns(10);
		t6.setBackground(Color.LIGHT_GRAY);
		t6.setBounds(185, 266, 286, 28);
		panel_3.add(t6);
		
		t7 = new JTextField();
		t7.setFont(new Font("굴림", Font.BOLD, 20));
		t7.setEditable(false);
		t7.setColumns(10);
		t7.setBackground(Color.LIGHT_GRAY);
		t7.setBounds(185, 318, 286, 28);
		panel_3.add(t7);
		
		t1.setText(rr_id);

		
		
		f.setLocation(x+300, y);
		f.setVisible(true);

	}
}
