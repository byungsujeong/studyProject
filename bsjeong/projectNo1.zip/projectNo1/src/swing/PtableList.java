package swing;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import dao.PtableDAO;
import dto.PtableDTO;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class PtableList {
	private static JTable table_1;

	public PtableList(int x, int y) throws Exception {

		PtableDAO dao = new PtableDAO();
		PtableDTO dto = new PtableDTO();
		ArrayList<PtableDTO> list = dao.list(dto);
		
		LocalDate today = LocalDate.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String[] rdate = new String[7];
		for (int i = 0; i < rdate.length; i++) {
			rdate[i] = today.plusDays(i).format(format);
		}
		
		String[] items = { "순번", "상품명", "가격"};
		Object[][] data = new Object[list.size()][];
		String[] p_id = new String[list.size()];
		
		for (int i = 0; i < data.length; i++) {
			dto = list.get(i);
			Object[] r = {i+1, dto.getP_name(), dto.getPrice()};
			data[i] = r;
		}
		
		for (int i = 0; i < p_id.length; i++) {
			dto = list.get(i);
			p_id[i] = dto.getP_id();
		}

		JFrame f = new JFrame();
		f.setSize(1200, 600);
		f.setTitle("놀이기구 시간표 정보");
		f.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.GRAY);
		panel.setLayout(null);
		panel.setBounds(12, 59, 1160, 492);
		f.getContentPane().add(panel);

		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBounds(12, 10, 1136, 43);
		panel.add(panel_1);
		panel_1.setBackground(Color.LIGHT_GRAY);

		JLabel lblNewLabel = new JLabel(" 예약 날짜 : ");
		lblNewLabel.setLocation(12, 10);
		lblNewLabel.setSize(165, 22);
		lblNewLabel.setFont(new Font("굴림", Font.BOLD, 14));
		panel_1.add(lblNewLabel);

		JComboBox comboBox = new JComboBox(rdate);
		comboBox.setLocation(131, 10);
		comboBox.setSize(295, 22);
		comboBox.setFont(new Font("굴림", Font.PLAIN, 16));
		panel_1.add(comboBox);

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setLayout(null);
		panel_2.setBounds(12, 10, 1160, 39);
		f.getContentPane().add(panel_2);

		JButton b1 = new JButton("로그아웃");
		b1.setFont(new Font("굴림", Font.BOLD, 14));
		b1.setBounds(838, 10, 149, 25);
		panel_2.add(b1);

		JButton b2 = new JButton("회원정보 수정");
		b2.setVerticalAlignment(SwingConstants.BOTTOM);
		b2.setFont(new Font("굴림", Font.BOLD, 14));
		b2.setBounds(999, 10, 149, 25);
		panel_2.add(b2);

		JLabel lblNewLabel_1 = new JLabel("회원님 환영합니다.");
		lblNewLabel_1.setBounds(713, 13, 113, 15);
		panel_2.add(lblNewLabel_1);

		JPanel panel_3 = new JPanel();
		panel_3.setBounds(12, 63, 1136, 419);
		panel.add(panel_3);
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_3.setLayout(null);

		JTable table_1 = new JTable(data, items);
		JScrollPane scrollPane = new JScrollPane(table_1);
		scrollPane.setBounds(12, 10, 847, 399);
		table_1.setBounds(12, 403, 641, -392);
		panel_3.add(scrollPane);

		JButton btnNewButton = new JButton("예약하기");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					SmartReserve name = new SmartReserve(f.getLocation().x, f.getLocation().y, p_id[table_1.getSelectedRow()], (String) comboBox.getSelectedItem(), "root");
				} catch (Exception e1) {
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null, "상품을 선택하세요.");
				}
				
			}
		});
		btnNewButton.setFont(new Font("굴림", Font.BOLD, 14));
		btnNewButton.setBounds(894, 373, 129, 36);
		panel_3.add(btnNewButton);

		JButton button = new JButton("뒤로가기");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					ReserveMain name = new ReserveMain(f.getLocation().x, f.getLocation().y);
					f.dispose();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});

		button.setFont(new Font("굴림", Font.BOLD, 14));
		button.setBounds(1027, 373, 97, 36);
		panel_3.add(button);

		f.setLocation(x, y);
		f.setVisible(true);

	}

}
