package main;

import javax.swing.JOptionPane;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int jop = JOptionPane.showConfirmDialog(null, "예약을 취소하시겠습니까?", "예약취소", 0, 3);
		
		System.out.println(jop);
		
		
		
		
		
		
	}

}
