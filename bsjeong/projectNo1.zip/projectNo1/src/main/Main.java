package main;

import swing.ReserveMain;

public class Main {

	public static void main(String[] args) {
		//17~23일
		ReserveMain name = new ReserveMain(50, 30);

	}

}
