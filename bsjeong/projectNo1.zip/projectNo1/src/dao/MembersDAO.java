package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import dto.MembersDTO;

public class MembersDAO {

	public MembersDTO getInfor(MembersDTO dto) throws Exception {
		
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. connector설정 성공...");

		String url = "jdbc:mysql://localhost:3306/projectno1";
		String user = "root";
		String password = "1q2w3e4r";

		Connection con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB연결 성공...");

		String sql = "select m_id, m_name from members where m_id = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, dto.getM_id());
		
		ResultSet rs = ps.executeQuery();
		
		if(rs.next()) {
			
			dto.setM_id(rs.getString(1));
			dto.setM_name(rs.getString(2));
			
		}
		
		rs.close();
		ps.close();
		con.close();
		
		return dto;
		
	}
	
}
