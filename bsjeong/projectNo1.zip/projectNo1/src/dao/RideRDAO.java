package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import dto.PtableDTO;
import dto.RideRDTO;
import dto.SmartRDTO;

public class RideRDAO {

	public void insert(RideRDTO dto) throws Exception {

		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. connector설정 성공...");

		String url = "jdbc:mysql://localhost:3306/projectno1";
		String user = "root";
		String password = "1q2w3e4r";

		Connection con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB연결 성공...");
		
		String sql = "insert into rider values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,now())";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, dto.getRr_id());
		ps.setString(2, dto.getR_name());
		ps.setString(3, dto.getSr_id());
		ps.setString(4, dto.getRdate());
		ps.setString(5, dto.getStime());
		ps.setString(6, dto.getFtime());
		ps.setString(7, dto.getBtime());
		ps.setString(8, dto.getM_id());
		ps.setString(9, dto.getR_id());
		ps.setInt(10, dto.getPeople());
		ps.setInt(11, dto.getR_Ltall());
		ps.setInt(12, dto.getR_Htall());
		ps.setInt(13, dto.getTall());
		ps.setString(14, dto.getT_id());
		ps.setString(15, dto.getAvailability());
		
		System.out.println("3. SQL문 결정 성공...");

		ps.executeUpdate();
		System.out.println("4. SQL문 전송 요청 성공...");

		ps.close();
		con.close();

	}
	
	public void delete(RideRDTO dto) throws Exception {
		
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. connector설정 성공...");

		String url = "jdbc:mysql://localhost:3306/projectno1";
		String user = "root";
		String password = "1q2w3e4r";

		Connection con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB연결 성공...");

		String sql = "delete from rider where rr_id=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, dto.getRr_id());
		System.out.println("3. SQL문 결정 성공...");

		ps.executeUpdate();
		System.out.println("4. SQL문 전송 요청 성공...");

		ps.close();
		con.close();
		
	}
	
	public void update(RideRDTO dto) throws Exception {
		
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. connector설정 성공...");

		String url = "jdbc:mysql://localhost:3306/projectno1";
		String user = "root";
		String password = "1q2w3e4r";

		Connection con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB연결 성공...");

		String sql = "update rider set r_name = ?, sr_id = ?, rdate = ?, stime = ?, ftime = ?, btime = ?, m_id = ?, r_id = ?,";
		String sql2 = "people = ?, r_ltall = ?, r_htall = ?, tall = ?, t_id = ?, availability = ? where rr_id = ?";
		PreparedStatement ps = con.prepareStatement(sql+sql2);
		ps.setString(1, dto.getR_name());
		ps.setString(2, dto.getSr_id());
		ps.setString(3, dto.getRdate());
		ps.setString(4, dto.getStime());
		ps.setString(5, dto.getFtime());
		ps.setString(6, dto.getBtime());
		ps.setString(7, dto.getM_id());
		ps.setString(8, dto.getR_id());
		ps.setInt(9, dto.getPeople());
		ps.setInt(10, dto.getR_Ltall());
		ps.setInt(11, dto.getR_Htall());
		ps.setInt(12, dto.getTall());
		ps.setString(13, dto.getT_id());
		ps.setString(14, dto.getAvailability());
		ps.setString(15, dto.getRr_id());
		System.out.println("3. SQL문 결정 성공...");

		ps.executeUpdate();
		System.out.println("4. SQL문 전송 요청 성공...");

		ps.close();
		con.close();
		
	}
	
}
