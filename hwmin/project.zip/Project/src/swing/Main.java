package swing;

import swing.ReserveMain;

public class Main {

	public static void main(String[] args) {
		
		ReserveMain name = new ReserveMain(50,50,"");
		System.out.println("test");
	}

}
