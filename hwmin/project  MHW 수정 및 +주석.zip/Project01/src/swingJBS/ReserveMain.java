package swingJBS;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import swingLHL.TtableInfo;
import swingMHW.Start;

import javax.swing.ImageIcon;
import java.awt.SystemColor;
import javax.swing.UIManager;

public class ReserveMain {

	public ReserveMain(int x, int y, String m_id) {
		      	       
	      JFrame f = new JFrame();
	      f.setSize(1200,600);
	      f.setTitle("놀이기구 시간표 정보");
	      f.getContentPane().setLayout(null);
	      
	      JPanel panel = new JPanel();
	      panel.setBackground(Color.GRAY);
	      panel.setLayout(null);
	      panel.setBounds(12, 59, 1160, 492);
	      f.getContentPane().add(panel);

	      JPanel panel_1 = new JPanel();
	      panel_1.setLayout(null);
	      panel_1.setBounds(12, 10, 1136, 43);
	      panel.add(panel_1);
	      panel_1.setBackground(Color.LIGHT_GRAY);

	      JLabel lblNewLabel = new JLabel(" 원하시는 서비스를 선택하세요.");
	      lblNewLabel.setLocation(12, 10);
	      lblNewLabel.setSize(291, 22);
	      lblNewLabel.setFont(new Font("굴림", Font.BOLD, 14));
	      panel_1.add(lblNewLabel);
	      
	      JPanel panel_2 = new JPanel();
	      panel_2.setBackground(Color.LIGHT_GRAY);
	      panel_2.setLayout(null);
	      panel_2.setBounds(12, 10, 1160, 39);
	      f.getContentPane().add(panel_2);

	      JButton b1 = new JButton("로그아웃");
	      b1.setFont(new Font("굴림", Font.BOLD, 14));
	      b1.setBounds(838, 10, 149, 25);
	      panel_2.add(b1);

	      JButton b2 = new JButton("회원정보 수정");
	      b2.setVerticalAlignment(SwingConstants.BOTTOM);
	      b2.setFont(new Font("굴림", Font.BOLD, 14));
	      b2.setBounds(999, 10, 149, 25);
	      panel_2.add(b2);

	      JLabel lblNewLabel_1 = new JLabel("회원님 환영합니다.");
	      lblNewLabel_1.setBounds(713, 13, 113, 15);
	      panel_2.add(lblNewLabel_1);
	      
	      JPanel panel_3 = new JPanel();
	      panel_3.setBounds(12, 63, 1136, 419);
	      panel.add(panel_3);
	      panel_3.setBorder(new LineBorder(new Color(0, 0, 0)));
	      panel_3.setLayout(null);
	     	      
	      JButton back = new JButton("뒤로가기");
	      back.addActionListener(new ActionListener() {
	      	public void actionPerformed(ActionEvent e) {
	      		Start name = new Start(f.getLocation().x, f.getLocation().y, m_id);
	      		f.dispose();
	      	}
	      });
	      
	      back.setFont(new Font("굴림", Font.BOLD, 14));
	      back.setBounds(1027, 373, 97, 36);
	      panel_3.add(back);
	      
	      JButton btnNewButton = new JButton("스마트 예약");
	      // btnNewButton.setIcon(new ImageIcon("picture/background.jpg"));
	      btnNewButton.setOpaque(false);
	      btnNewButton.addActionListener(new ActionListener() {
	      	public void actionPerformed(ActionEvent e) {
	      		
	      		try {
					PtableList name = new PtableList(f.getLocation().x, f.getLocation().y, m_id);
					f.dispose();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	      		
	      	}
	      });
	      btnNewButton.setBounds(54, 71, 200, 200);
	      panel_3.add(btnNewButton);
	      
	      JButton btnNewButton_1 = new JButton("놀이기구 예약");
	      // btnNewButton_1.setIcon(new ImageIcon("picture/background2.jpg"));
	      btnNewButton_1.addActionListener(new ActionListener() {
	      	public void actionPerformed(ActionEvent e) {
	      		try {
					TtableInfo name = new TtableInfo(f.getLocation().x, f.getLocation().y, "", m_id);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	      		f.dispose();
	      	}
	      });
	      btnNewButton_1.setBounds(595, 71, 200, 200);
	      panel_3.add(btnNewButton_1);
	      
	      JButton btnNewButton_2 = new JButton("스마트 예약확인");
	     // btnNewButton_2.setIcon(new ImageIcon("picture/background3.jpg"));
	      btnNewButton_2.addActionListener(new ActionListener() {
	      	public void actionPerformed(ActionEvent e) {
	      		
	      		try {
					SmartCheck name = new SmartCheck(f.getLocation().x, f.getLocation().y, m_id);
					f.dispose();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	      	}
	      });
	      btnNewButton_2.setBounds(321, 71, 200, 200);
	      panel_3.add(btnNewButton_2);
	      
	      JButton btnNewButton_3 = new JButton("놀이기구 예약확인");
	     // btnNewButton_3.setIcon(new ImageIcon("picture/background4.jpg"));
	      btnNewButton_3.addActionListener(new ActionListener() {
	      	public void actionPerformed(ActionEvent e) {
	      		
	      		try {
					RideCheck name = new RideCheck(f.getLocation().x, f.getLocation().y, m_id);
					f.dispose();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	      	}
	      });
	      btnNewButton_3.setBounds(884, 71, 200, 200);
	      panel_3.add(btnNewButton_3);
	      
	      JLabel lblNewLabel_2 = new JLabel("스마트 예약확인");
	      lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
	      lblNewLabel_2.setBounds(321, 281, 200, 49);
	      panel_3.add(lblNewLabel_2);
	      
	      JLabel label = new JLabel("스마트 예약");
	      label.setHorizontalAlignment(SwingConstants.CENTER);
	      label.setBounds(54, 281, 200, 49);
	      panel_3.add(label);
	      
	      JLabel label_1 = new JLabel("놀이기구 얘약");
	      label_1.setHorizontalAlignment(SwingConstants.CENTER);
	      label_1.setBounds(595, 281, 200, 49);
	      panel_3.add(label_1);
	      
	      JLabel label_2 = new JLabel("놀이기구 예약확인");
	      label_2.setHorizontalAlignment(SwingConstants.CENTER);
	      label_2.setBounds(884, 281, 200, 49);
	      panel_3.add(label_2);
	      
	      f.setLocation(x, y);
	      f.setVisible(true);
	      
	}
}
