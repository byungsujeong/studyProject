package swingJBS;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import dao.PtableDAO;
import dao.RideRDAO;
import dao.SmartRDAO;
import dto.MembersDTO;
import dto.PtableDTO;
import dto.RideRDTO;
import dto.SmartRDTO;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.JTextField;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;

public class RideCheck {

	public RideCheck(int x, int y, String m_id) throws Exception {

		String[] items = { "예약번호", "놀이기구명", "예약날짜", "탑승시간", "시작시간", "종료시간","예약자ID", "예약자"};
		
		DefaultTableModel model = new DefaultTableModel(items, 0);
		
		JFrame f = new JFrame();
		
		f.setSize(1200, 600);
		f.setTitle("놀이기구 시간표 정보");
		f.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.GRAY);
		panel.setLayout(null);
		panel.setBounds(12, 59, 1160, 492);
		f.getContentPane().add(panel);

		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBounds(12, 10, 1136, 43);
		panel.add(panel_1);
		panel_1.setBackground(Color.LIGHT_GRAY);

		JLabel lblNewLabel = new JLabel(" 예약번호 : ");
		lblNewLabel.setLocation(12, 10);
		lblNewLabel.setSize(165, 22);
		lblNewLabel.setFont(new Font("굴림", Font.BOLD, 14));
		panel_1.add(lblNewLabel);

		JTextField t1 = new JTextField();
		t1.setBounds(107, 10, 211, 22);
		panel_1.add(t1);
		t1.setColumns(10);
	
		JButton btnNewButton_1 = new JButton("조회");
		btnNewButton_1.setBounds(330, 10, 97, 24);
		panel_1.add(btnNewButton_1);

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setLayout(null);
		panel_2.setBounds(12, 10, 1160, 39);
		f.getContentPane().add(panel_2);

		JButton b1 = new JButton("로그아웃");
		b1.setFont(new Font("굴림", Font.BOLD, 14));
		b1.setBounds(838, 10, 149, 25);
		panel_2.add(b1);

		JButton b2 = new JButton("회원정보 수정");
		b2.setVerticalAlignment(SwingConstants.BOTTOM);
		b2.setFont(new Font("굴림", Font.BOLD, 14));
		b2.setBounds(999, 10, 149, 25);
		panel_2.add(b2);

		JLabel lblNewLabel_1 = new JLabel("회원님 환영합니다.");
		lblNewLabel_1.setBounds(713, 13, 113, 15);
		panel_2.add(lblNewLabel_1);

		JPanel panel_3 = new JPanel();
		panel_3.setBounds(12, 63, 1136, 419);
		panel.add(panel_3);
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_3.setLayout(null);

		JTable table_1 = new JTable(model);
		table_1.setBounds(12, 403, 641, -392);
		JScrollPane scrollPane = new JScrollPane(table_1);
		scrollPane.setBounds(12, 10, 847, 399);
		panel_3.add(scrollPane);

		JButton btnNewButton = new JButton("예약취소");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				RideRDTO rideRDTO = new RideRDTO();
				RideRDAO rideRDAO = new RideRDAO();
				rideRDTO.setRr_id((String) model.getValueAt(table_1.getSelectedRow(), 0));
				
				try {
					int jop = JOptionPane.showConfirmDialog(null, "예약을 취소하시겠습니까?", "예약취소", 0, 3);
					if(jop==0) {
						rideRDAO.delete(rideRDTO);
					}
				} catch (Exception e1) {
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null, "예약내역을 선택하세요.");
				}
				
			}
		});
		btnNewButton.setFont(new Font("굴림", Font.BOLD, 14));
		btnNewButton.setBounds(894, 373, 129, 36);
		panel_3.add(btnNewButton);
		
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.setRowCount(0);
				
				RideRDTO rideRDTO = new RideRDTO();
				RideRDAO rideRDAO = new RideRDAO();
				Object[][] data;
				if (m_id.equals("root")) {
					ArrayList<RideRDTO> list;
					try {
						rideRDTO.setRr_id(t1.getText());
						list = rideRDAO.listAdmin(rideRDTO);
						data = new Object[list.size()][];
						for (int i = 0; i < data.length; i++) {
							rideRDTO = list.get(i);
							Object[] r = { rideRDTO.getRr_id(), rideRDTO.getR_name(), rideRDTO.getRdate(),
									rideRDTO.getBtime(), rideRDTO.getStime(), rideRDTO.getFtime(),rideRDTO.getM_id(), rideRDTO.getM_name() };
							model.addRow(r);
							data[i] = r;
						}
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				} else {
					rideRDTO.setRr_id(t1.getText());
					rideRDTO.setM_id(m_id);
					try {
						ArrayList<RideRDTO> list = rideRDAO.list(rideRDTO);
						data = new Object[list.size()][];
						for (int i = 0; i < data.length; i++) {
							rideRDTO = list.get(i);
							Object[] r = {  rideRDTO.getRr_id(), rideRDTO.getR_name(), rideRDTO.getRdate(),
									rideRDTO.getBtime(), rideRDTO.getStime(), rideRDTO.getFtime(),rideRDTO.getM_id(), rideRDTO.getM_name() };
							model.addRow(r);
							data[i] = r;
						}
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				t1.setText(null);
			}
		});

		
		JButton button = new JButton("뒤로가기");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					ReserveMain name = new ReserveMain(f.getLocation().x, f.getLocation().y, m_id);
					f.dispose();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});

		button.setFont(new Font("굴림", Font.BOLD, 14));
		button.setBounds(1027, 373, 97, 36);
		panel_3.add(button);
		
		f.addWindowFocusListener(new WindowFocusListener() {
			public void windowGainedFocus(WindowEvent e) {
				btnNewButton_1.doClick();
			}
			public void windowLostFocus(WindowEvent e) {
			}
		});
		
		f.setLocation(x, y);
		f.setVisible(true);

	}

}
