// 놀이기구정보 메인

package swing;

public class RideMain {

	public static void main(String[] args) throws Exception {
		
		RideInfo name = new RideInfo("글로벌 페어");

	}

}
