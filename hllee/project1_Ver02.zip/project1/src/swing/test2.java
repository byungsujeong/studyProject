// 위치별 놀이기구 종류

package swing;

public class test2 {

	public static void main(String[] args) throws Exception {
		
		test name = new test();

	}

}