// 해당 놀이기구 정보

package swing;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import java.awt.Font;

import java.awt.Image;

import javax.swing.SwingConstants;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;


import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import DAO.RideDAO;
import DAO.TtableDAO;
import DTO.RideDTO;
import DTO.TtableDTO;

import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import javax.swing.UIManager;
import javax.swing.DefaultComboBoxModel;


public class TtableInsert {
	private JTextField tname;
		
	public TtableInsert(){
		
		RideDTO rideDTO = new RideDTO();
		RideDAO rideDAO = new RideDAO();
		
		
//////////------------- 프레임 생성  ------------- //////////
		JFrame f = new JFrame();
		f.setSize(1200, 600);
		f.setTitle("놀이기구 상세정보");
		f.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.GRAY);
		panel.setLayout(null);
		panel.setBounds(12, 59, 1160, 492);
		f.getContentPane().add(panel);

//////////- 회원정보 패널(로그아웃+회원정보수정+로그인정보) - ////////		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setLayout(null);
		panel_2.setBounds(12, 10, 1160, 39);
		f.getContentPane().add(panel_2);

		// 로그아웃 버튼
		JButton b1 = new JButton("로그아웃");
		b1.setFont(new Font("굴림", Font.BOLD, 14));
		b1.setBounds(838, 10, 149, 25);
		panel_2.add(b1);

		// 회원정보 수정 버튼
		JButton b2 = new JButton("회원정보 수정");
		b2.setVerticalAlignment(SwingConstants.BOTTOM);
		b2.setFont(new Font("굴림", Font.BOLD, 14));
		b2.setBounds(999, 10, 149, 25);
		panel_2.add(b2);

		// 로그인 정보 레이블
		JLabel lblNewLabel_1 = new JLabel("회원님 환영합니다.");
		lblNewLabel_1.setBounds(713, 13, 113, 15);
		panel_2.add(lblNewLabel_1);

//////////---------- 놀이기구 관리설정 콤보박스 ---------- //////////
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBounds(12, 10, 1136, 43);
		panel.add(panel_1);
		panel_1.setBackground(Color.LIGHT_GRAY);

		// 놀이기구 이름 레이블 생성
		JLabel lblNewLabel = new JLabel("놀이기구 시간표를 입력하세요.");
		lblNewLabel.setLocation(12, 10);
		lblNewLabel.setSize(400, 22);
		lblNewLabel.setFont(new Font("굴림", Font.BOLD, 14));
		panel_1.add(lblNewLabel);
		
		
////////////---------- 놀이기구  정보 패널 ---------- ////////// 
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(12, 63, 1136, 419);
		panel.add(panel_3);
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_3.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 10, 1112, 360);
		panel_3.add(scrollPane);
		
		JPanel panel_4 = new JPanel();
		scrollPane.setViewportView(panel_4);
		panel_4.setLayout(null);
		
////////////---------- 놀이기구  정보 내용 (레이블+텍스트필드) ---------- ////////// 
		
		// 놀이기구 아이디(레이블+텍스트)
		JLabel labelId = new JLabel("시간표 아이디");
		labelId.setFont(new Font("굴림", Font.BOLD, 18));
		labelId.setBounds(23, 10, 163, 25);
		panel_4.add(labelId);
		
		JTextField ttid = new JTextField();
		ttid.setFont(new Font("굴림", Font.PLAIN, 15));
		ttid.setBounds(198, 10, 316, 25);
		panel_4.add(ttid);
		ttid.setColumns(10);
		
		// 놀이기구 이름(레이블+텍스트)
		JLabel label = new JLabel("놀이기구 아이디");
		label.setFont(new Font("굴림", Font.BOLD, 18));
		label.setBounds(23, 50, 163, 25);
		panel_4.add(label);
		
		JTextField trid = new JTextField();
		trid.setFont(new Font("굴림", Font.PLAIN, 15));
		trid.setColumns(10);
		trid.setBounds(198, 50, 316, 25);
		panel_4.add(trid);
		
		
	
		
		
		
		JTextField tstime = new JTextField();
		tstime.setFont(new Font("굴림", Font.PLAIN, 15));
		tstime.setColumns(10);
		tstime.setBounds(198, 130, 316, 25);
		panel_4.add(tstime);
		
		JTextField tftime = new JTextField();
		tftime.setFont(new Font("굴림", Font.PLAIN, 15));
		tftime.setColumns(10);
		tftime.setBounds(198, 170, 316, 25);
		panel_4.add(tftime);
		
		JTextField tbtime = new JTextField();
		tbtime.setFont(new Font("굴림", Font.PLAIN, 15));
		tbtime.setColumns(10);
		tbtime.setBounds(198, 210, 316, 25);
		panel_4.add(tbtime);
		
		JLabel label_1 = new JLabel("놀이기구 이름");
		label_1.setFont(new Font("굴림", Font.BOLD, 18));
		label_1.setBounds(23, 90, 163, 25);
		panel_4.add(label_1);
		
		JLabel label_2 = new JLabel("운행시작시간");
		label_2.setFont(new Font("굴림", Font.BOLD, 18));
		label_2.setBounds(23, 130, 163, 25);
		panel_4.add(label_2);
		
		JLabel label_3 = new JLabel("운행종료시간");
		label_3.setFont(new Font("굴림", Font.BOLD, 18));
		label_3.setBounds(23, 170, 163, 25);
		panel_4.add(label_3);
		
		JLabel label_4 = new JLabel("탑승시간");
		label_4.setFont(new Font("굴림", Font.BOLD, 18));
		label_4.setBounds(23, 210, 163, 25);
		panel_4.add(label_4);
		
		tname = new JTextField();
		tname.setFont(new Font("굴림", Font.PLAIN, 15));
		tname.setColumns(10);
		tname.setBounds(198, 90, 316, 25);
		panel_4.add(tname);
			
//////////------------- 추가하기 버튼  ------------- //////////	
		
		TtableDAO dao = new TtableDAO();
		TtableDTO dto = new TtableDTO();
		
		JButton insertbtn = new JButton("추가하기");
		insertbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					String t_id = ttid.getText();
					String r_id = trid.getText();
					String r_name = tname.getText();
					String stime = tstime.getText();
					String ftime = tftime.getText();
					String btime = tbtime.getText();
					
					dto.setT_id(t_id);
					dto.setR_id(r_id);
					dto.setR_name(r_name);
					dto.setStime(stime);;
					dto.setFtime(ftime);;
					dto.setBtime(btime);;
					
					
					dao.insert(dto);
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		
		insertbtn.setFont(new Font("굴림", Font.BOLD, 14));
		insertbtn.setBounds(924, 373, 97, 36);
		panel_3.add(insertbtn);
				

//////////------------- 닫기  버튼  ------------- //////////			 
		
		JButton cbtn = new JButton("닫기");
	
		cbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
						f.dispose();
						String r_name = tname.getText();
						TtableInfo name = new TtableInfo(r_name);
					
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
			}
		});
		
		cbtn.setFont(new Font("굴림", Font.BOLD, 14));
		cbtn.setBounds(1027, 373, 97, 36);
		panel_3.add(cbtn);
				
		
		f.setVisible(true);

	}
}