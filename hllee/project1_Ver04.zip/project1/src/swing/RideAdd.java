package swing;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JTextPane;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JScrollBar;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;

import DAO.RideDAO;
import DTO.RideDTO;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.DefaultComboBoxModel;

public class RideAdd {
	private static JTextField tid;
	private static JTextField tname;
	private static JTextField tpeople;
	private static JTextField tltall;
	private static JTextField thtall;
	private static JTextField tltime;
	private static JTextField timg;

	public RideAdd() {
		
//////////------------- 프레임 생성  ------------- //////////
		JFrame f = new JFrame();
		f.setSize(600, 600);
		f.setTitle("놀이기구 추가");
		f.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setLayout(null);
		panel.setBounds(12, 54, 560, 497);
		f.getContentPane().add(panel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.GRAY);
		panel_1.setBounds(12, 10, 560, 40);
		f.getContentPane().add(panel_1);
		
		JLabel labelSwingName = new JLabel("놀이기구 추가하기");
		panel_1.add(labelSwingName);
		labelSwingName.setHorizontalAlignment(SwingConstants.CENTER);
		labelSwingName.setFont(new Font("굴림", Font.BOLD, 25));
		
		
		JLabel lblNewLabel = new JLabel("Id");
		lblNewLabel.setFont(new Font("굴림", Font.BOLD, 18));
		lblNewLabel.setBounds(23, 10, 163, 25);
		panel.add(lblNewLabel);
		
		tid = new JTextField();
		tid.setFont(new Font("굴림", Font.PLAIN, 15));
		tid.setBounds(198, 10, 316, 25);
		panel.add(tid);
		tid.setColumns(10);
		
		tname = new JTextField();
		tname.setFont(new Font("굴림", Font.PLAIN, 15));
		tname.setColumns(10);
		tname.setBounds(198, 50, 316, 25);
		panel.add(tname);
		
		JLabel label = new JLabel("이름");
		label.setFont(new Font("굴림", Font.BOLD, 18));
		label.setBounds(23, 50, 163, 25);
		panel.add(label);
		
		JLabel label_1 = new JLabel("위치");
		label_1.setFont(new Font("굴림", Font.BOLD, 18));
		label_1.setBounds(23, 90, 163, 25);
		panel.add(label_1);
		
		tpeople = new JTextField();
		tpeople.setFont(new Font("굴림", Font.PLAIN, 15));
		tpeople.setColumns(10);
		tpeople.setBounds(198, 130, 316, 25);
		panel.add(tpeople);
		
		JLabel label_2 = new JLabel("정원");
		label_2.setFont(new Font("굴림", Font.BOLD, 18));
		label_2.setBounds(23, 130, 163, 25);
		panel.add(label_2);
		
		
		
		JLabel label_3 = new JLabel("최소키");
		label_3.setFont(new Font("굴림", Font.BOLD, 18));
		label_3.setBounds(23, 170, 163, 25);
		panel.add(label_3);
		
		tltall = new JTextField();
		tltall.setFont(new Font("굴림", Font.PLAIN, 15));
		tltall.setColumns(10);
		tltall.setBounds(198, 170, 316, 25);
		panel.add(tltall);
		
		JLabel label_4 = new JLabel("최대키");
		label_4.setFont(new Font("굴림", Font.BOLD, 18));
		label_4.setBounds(23, 210, 163, 25);
		panel.add(label_4);
		
		thtall = new JTextField();
		thtall.setFont(new Font("굴림", Font.PLAIN, 15));
		thtall.setColumns(10);
		thtall.setBounds(198, 210, 316, 25);
		panel.add(thtall);
		
		JLabel label_5 = new JLabel("소요시간");
		label_5.setFont(new Font("굴림", Font.BOLD, 18));
		label_5.setBounds(23, 250, 163, 25);
		panel.add(label_5);
		
		tltime = new JTextField();
		tltime.setFont(new Font("굴림", Font.PLAIN, 15));
		tltime.setColumns(10);
		tltime.setBounds(198, 250, 316, 25);
		panel.add(tltime);
		
		JLabel label_6 = new JLabel("예약 가능 여부");
		label_6.setFont(new Font("굴림", Font.BOLD, 18));
		label_6.setBounds(23, 380, 163, 25);
		panel.add(label_6);
		
		JLabel label_7 = new JLabel("내용");
		label_7.setFont(new Font("굴림", Font.BOLD, 18));
		label_7.setBounds(23, 290, 163, 25);
		panel.add(label_7);
		
		JTextPane tcontent = new JTextPane();
		tcontent.setBounds(198, 330, 316, 100);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(198, 290, 316, 83);
		scrollPane.setViewportView(tcontent);
		panel.add(scrollPane);

		JLabel label_8 = new JLabel("이미지");
		label_8.setFont(new Font("굴림", Font.BOLD, 18));
		label_8.setBounds(23, 420, 163, 25);
		panel.add(label_8);
		
		timg = new JTextField();
		timg.setFont(new Font("굴림", Font.PLAIN, 15));
		timg.setColumns(10);
		timg.setBounds(198, 420, 316, 25);
		panel.add(timg);
		
		// 놀이기구 위치 콤보박스 생성
		JComboBox combolocation = new JComboBox();
		
		RideDAO dao = new RideDAO();
		RideDTO dto = new RideDTO();
	
		ArrayList<RideDTO> locationlist;
		try {
			locationlist = dao.selectlocation();
			Object[] data = new Object[locationlist.size()];
			for (int i = 0; i < data.length; i++) {
				RideDTO locationdto = locationlist.get(i);
				data[i] = locationdto.getLocation();
				combolocation.addItem(data[i]);
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
		combolocation.setFont(new Font("굴림", Font.PLAIN, 15));
		combolocation.setBounds(198, 90, 316, 25);
		panel.add(combolocation);
		
		// 놀이기구 예약가능 여부 콤보박스 생성
		JComboBox comboability = new JComboBox();
		comboability.setModel(new DefaultComboBoxModel(new String[] {"가능", "불가능"}));
		comboability.setBounds(198, 380, 316, 25);
		panel.add(comboability);
		
////////////---------- 놀이기구 정보 입력 ---------- //////////		
		JButton addbtn = new JButton("추가하기");
		addbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
				
					String r_id = tid.getText();
					String r_name = tname.getText();
					String location = (String) combolocation.getSelectedItem();
					System.out.println(location);
					int people = Integer.parseInt(tpeople.getText());
					int r_ltall = Integer.parseInt(tltall.getText());
					int r_htall = Integer.parseInt(thtall.getText());
					int ltime = Integer.parseInt(tltime.getText());
					String r_content = tcontent.getText();
					String availability = (String) comboability.getSelectedItem();
					String img = timg.getText();
					
					dto.setR_id(r_id);
					dto.setR_name(r_name);
					dto.setLocation(location);
					dto.setPeople(people);
					dto.setR_ltall(r_ltall);
					dto.setR_htall(r_htall);
					dto.setLtime(ltime);
					dto.setR_content(r_content);
					dto.setAvailability(availability);
					dto.setImg(img);
					
					dao.insert(dto);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
		});
		addbtn.setBounds(311, 451, 97, 36);
		panel.add(addbtn);
		
		JButton button = new JButton("닫기");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		button.setBounds(417, 451, 97, 36);
		panel.add(button);
		
		
		
		
		
		
		
		f.setVisible(true);

	}
}
