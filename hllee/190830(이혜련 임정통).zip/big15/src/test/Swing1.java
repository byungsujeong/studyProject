package test;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Swing1 extends JFrame{
	JButton b;
	
	public Swing1() {
		setTitle("swing1");
		setSize(500, 500);
		
		setLayout(new FlowLayout());
		
		b = new JButton("일어나기");

		add(b);

		
		Event t1 = new Event();
		
		b.addActionListener(t1);
		
		setVisible(true);
	}

	
	
	public static void main(String[] args) {
		Swing1 name = new Swing1();
	}
	
}
