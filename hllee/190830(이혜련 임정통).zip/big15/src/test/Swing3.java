package test;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Swing3 extends JFrame{
	JButton b1, b2, b3;
	
	public Swing3() {
		setTitle("swing3");
		setSize(500, 500);
		setLayout(new FlowLayout());
		
		b1 = new JButton("아침식사");
		b2 = new JButton("점심식사");
		b3 = new JButton("저녁식사");
		
		add(b1);
		add(b2);
		add(b3);
		
		b1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "시리얼");
				
			}
		});
		
		b2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "부대찌개");
				
			}
		});
		
		b3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "삼겹살");
				
			}
		});
		
		
		
		setVisible(true);
		

		
	}
	
	
	
	
	public static void main(String[] args) {
		Swing3 name = new Swing3();

	}

}
