package test;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Swing2 extends JFrame implements ActionListener{

	JButton b1, b2, b3;
	
	public Swing2() {
		setTitle("swing2");
		setSize(500, 500);
		setLayout(new FlowLayout());
		
		b1 = new JButton("조깅하기");
		b2 = new JButton("산책하기");
		b3 = new JButton("등산하기");
		
		add(b1);
		add(b2);
		add(b3);
				
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		
		setVisible(true);
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == b1) {
			JOptionPane.showMessageDialog(null, "조깅을 합니다.");
		}
		if (e.getSource() == b2) {
			JOptionPane.showMessageDialog(null, "산책을 합니다.");
		}
		if (e.getSource() == b3) {
			JOptionPane.showMessageDialog(null, "등산을 합니다.");
		}
		
	}

	public static void main(String[] args) {
		Swing2 name = new Swing2();
	}
	
	
}
