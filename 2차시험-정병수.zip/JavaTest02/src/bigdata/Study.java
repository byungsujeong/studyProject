package bigdata;

public class Study {

	// 변수 선언(수강아이디, 수강과목, 수강내용, 수강비용, 수강가능인원)
	String id;
	String subject;
	String content;
	int price;
	int capacity;
	
	// 객체에 모든 내용이 포함되어야 만들어 지도록 Constructor 정의
	public Study(String id, String subject, String content, int price, int capacity) {
		super();
		this.id = id;
		this.subject = subject;
		this.content = content;
		this.price = price;
		this.capacity = capacity;
	}

	// 화면에 클래스 내의 모든 속성값들을 출력할 수 있도록 메소드 정의
	@Override
	public String toString() {
		return "Study [id=" + id + ", subject=" + subject + ", content=" + content + ", price=" + price + ", capacity="
				+ capacity + "]";
	}

}
