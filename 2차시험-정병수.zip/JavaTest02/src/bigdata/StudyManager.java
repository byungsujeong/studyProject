package bigdata;

import java.util.ArrayList;
import java.util.Scanner;

public class StudyManager {

	public static void main(String[] args) {
		// 시스템 종료 flag
		int flag = 0;

		// 데이터 넣을 ArrayList타입 변수선언
		ArrayList<Study> list = new ArrayList();

		while (flag == 0) {
			// 메뉴 선택할 수 있도록 스캐너 객체 생성
			Scanner sc = new Scanner(System.in);
			System.out.print("1.입력 2.출력 3.수정 4.정리 5.종료 >> ");
			int menu = sc.nextInt();
			System.out.println("============================");

			// switch-case문으로 생성한 메뉴선택 기능 생성
			switch (menu) {
			case 1:
				System.out.println("입력 화면입니다.");
				System.out.print("수강아이디를 입력하세요 : ");
				String id = sc.next();
				System.out.print("수강과목을 입력하세요 : ");
				String subject = sc.next();
				System.out.print("수강내용을 입력하세요 : ");
				String content = sc.next();
				System.out.print("수강비용을 입력하세요 : ");
				int price = sc.nextInt();
				System.out.print("수강가능 인원을 입력하세요 : ");
				int capacity = sc.nextInt();

				Study study = new Study(id, subject, content, price, capacity);
				list.add(study);
				
				System.out.println("============================");
				break;
			case 2:
				System.out.println("출력 화면입니다.");
				for (int i = 0; i < list.size(); i++) {
					System.out.println(list.get(i));
				}
				System.out.println("============================");
				break;
			case 3:
				System.out.println("수정 화면입니다.");
				System.out.print("수강아이디를 입력하세요 : ");
				id = sc.next();
				System.out.print("변경할 수강비용을 입력하세요 : ");
				price = sc.nextInt();
				
				// 입력한 id와 일치하는 인덱스 찾기 위한 for문
				for (int i = 0; i < list.size(); i++) {
					if(list.get(i).id.equals(id)) {
						// 일치하는 인덱스 찾아서 Study타입으로 가져와서 수정하기
						Study studyM = new Study(list.get(i).id, list.get(i).subject, list.get(i).content, price, list.get(i).capacity);
						list.set(i, studyM);			
					}
				}
				System.out.println("============================");
				break;
			case 4:
				System.out.println("정리 화면입니다.");
				// sum : 입력된 과목수(list.size())만큼 for문 실행하여 price값 모두 더하기
				int sum = 0;
				for (int i = 0; i < list.size(); i++) {
					sum = sum + list.get(i).price;					
				}
				// avg : 위 sum값을 과목수(list.size())로 나누기
				int avg = sum/list.size();
				System.out.println("수강비용의 합계는 " + sum + "입니다.");
				System.out.println("수강비용의 평균은 " + avg + "입니다.");				
				System.out.println("============================");
				break;
			default:
				System.out.println("시스템을 종료 합니다.");
				System.out.println("============================");
				flag = 1; // 무한루프 while문 종료 하기 위한 플래그
				break;
			}

		}

	}

}
