package projectno1;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTabbedPane;
import java.awt.ScrollPane;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;

public class 목록 {
	private static JTextField t1;
	private static JTable table;

	public 목록(int x, int y) throws Exception {
	// 테이블 항목명 입력
		String[] items = { "b_id", "title", "m_id", "uDate", "hits" };
		//모델 불러오기(필드명,레코드수)
		DefaultTableModel model = new DefaultTableModel(items,0);
		
		BoardDAO dao = new BoardDAO();
	// 배열리스트 생성
		ArrayList<BoardDTO> list = dao.selectAll();

		Object[][] data = new Object[list.size()][];
		for (int i = 0; i < list.size(); i++) {
			BoardDTO dto = list.get(i);
			Object[] r = { dto.getB_id(), dto.getTitle(), dto.getM_id(), dto.getuDate(), dto.getHits() };
			model.addRow(r); //모델에 배열변수 r을 올림
			data[i] = r;
		}

//		Object[][] data = { 
//				{ "5", "마", "e", "2019-08-16", "5" },
//				{ "4", "라", "d", "2019-08-15", "4" },
//				{ "3", "다", "c", "2019-08-14", "3" },
//				{ "2", "나", "b", "2019-08-13", "2" },
//				{ "1", "가", "a", "2019-08-12", "1" }
//		};

	// 프레임 생성
		JFrame f = new JFrame();
		f.setSize(1200, 600);
		f.getContentPane().setLayout(null);

	// 패널 생성
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1184, 561);
		f.getContentPane().add(panel);
		panel.setLayout(null);

	// 테이블 생성
		table = new JTable(model); //JTable에 모델이란 변수를 올림
		table.addMouseListener(new MouseAdapter() {

		// 클릭하면 화면전환, 글확인화면으로
		@Override
		public void mouseClicked(MouseEvent e) {
			int index = (int) data[table.getSelectedRow()][0];
			글확인 name = new 글확인(f.getLocation().x, f.getLocation().y, index);
			f.dispose();
			}
		});
	// 스크롤 생성
		JScrollPane scrollPane = new JScrollPane(table); //스크롤에 테이블 올림
		scrollPane.setBounds(110, 66, 966, 354);
		panel.add(scrollPane); //패널에 스크롤 올림

	// page 라벨
		JLabel lblNewLabel = new JLabel("Page");
		lblNewLabel.setBounds(375, 447, 57, 15);
		panel.add(lblNewLabel);

	// 페이지 버튼1 임시
		JButton b_p1 = new JButton("1");
		b_p1.setFont(new Font("굴림", Font.PLAIN, 7));
		b_p1.setBounds(444, 443, 39, 23);
		panel.add(b_p1);

	// 페이지 버튼2 임시
		JButton b_p2 = new JButton("2");
		b_p2.setFont(new Font("굴림", Font.PLAIN, 7));
		b_p2.setBounds(484, 443, 39, 23);
		panel.add(b_p2);

	// 페이지 버튼3 임시
		JButton b_p3 = new JButton("3");
		b_p3.setFont(new Font("굴림", Font.PLAIN, 7));
		b_p3.setBounds(523, 443, 39, 23);
		panel.add(b_p3);

	// 페이지 버튼4 임시
		JButton b_p4 = new JButton("4");
		b_p4.setFont(new Font("굴림", Font.PLAIN, 7));
		b_p4.setBounds(562, 443, 39, 23);
		panel.add(b_p4);

	// 페이지 버튼5 임시
		JButton b_p5 = new JButton("5");
		b_p5.setFont(new Font("굴림", Font.PLAIN, 7));
		b_p5.setBounds(603, 443, 39, 23);
		panel.add(b_p5);

	// 로그인 버튼
		JButton b_l1 = new JButton("로그인");
		b_l1.setBounds(854, 10, 105, 32);
		panel.add(b_l1);

	// 회원가입 버튼
		JButton b_l2 = new JButton("회원가입");
		b_l2.setBounds(971, 10, 105, 32);
		panel.add(b_l2);

	// 검색창
		t1 = new JTextField();
		t1.setBounds(375, 484, 267, 21);
		panel.add(t1);
		t1.setColumns(10);

	// 검색 버튼, 검색할 id를 입력하고 누르면 해당하는 글만 검색해서 띄우게 해야함
		JButton b_d = new JButton("검색");
		b_d.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				table = new JTable(model); //JTable에 모델이란 변수를 올림
				table.addMouseListener(new MouseAdapter() {
					
					// 클릭하면 화면전환, 글확인화면으로
					@Override
					public void mouseClicked(MouseEvent e) {
						int index = (int) data[table.getSelectedRow()][0]; //테이블 행의 위치값 설정
						글확인 name = new 글확인(f.getLocation().x, f.getLocation().y, index);
						f.dispose();
						}
					});
					
			
				
				model.setRowCount(0); //모델의 행의수를 0으로 설정 1차 검색 후 2차 검색시 데이터가 계속 쌓이는 것을 방지하기 위해
				
				BoardDTO dto = new BoardDTO();
				dto.setM_id(t1.getText());

				ArrayList<BoardDTO> listS;
				try {
					listS = dao.selectS(dto);
					Object[][] dataS = new Object[listS.size()][];
					for (int i = 0; i < listS.size(); i++) {
						dto = listS.get(i);
						Object[] rS = { dto.getB_id(), dto.getTitle(), dto.getM_id(), dto.getuDate(), dto.getHits() };
						model.addRow(rS); //모델에 배열변수 rs를 올림
						dataS[i] = rS;
					}

					table = new JTable(dataS, items);

				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});

		
		b_d.setFont(new Font("굴림", Font.PLAIN, 12));
		b_d.setBounds(654, 483, 69, 23);
		panel.add(b_d);

	// 글작성 버튼, 누르면 글작성화면으로 이동
		JButton b_w = new JButton("글작성");
		b_w.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				글작성 name = new 글작성(f.getLocation().x, f.getLocation().y);
				f.dispose();
			}

		});
		b_w.setBounds(862, 483, 97, 23);
		panel.add(b_w);
	
	// 목록가기 버튼, 누르면 목록화면으로 이동
		JButton b_t = new JButton("목록가기");
		b_t.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					목록 name = new 목록(f.getLocation().x,f.getLocation().y);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				f.dispose();
				
			}
		});
		b_t.setBounds(979, 483, 97, 23);
		panel.add(b_t);	

		f.setLocation(x, y);
		f.setVisible(true);

	}

}
