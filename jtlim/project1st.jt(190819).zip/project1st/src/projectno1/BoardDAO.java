package projectno1;

import java.sql.*;
import java.util.ArrayList;

import javax.print.DocFlavor.STRING;
import javax.swing.JOptionPane;


public class BoardDAO {

	
//update
	public void update(BoardDTO dto) throws Exception {
		
		// 1. connector(driver) 설정
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. connector설정 성공...");

		// 디비버에서 정보를 보고 밑에 세개 입력 //접근권한이 있어야 연결되게 하려고
		String url = "jdbc:mysql://localhost:3306/board";
		String user = "root";
		String password = "1234";

		// 2. DB연결
		Connection con = DriverManager.getConnection(url, user, password); // 오버로딩 중 3개짜리 선택
		System.out.println("2. db연결 성공...");

		// 3. SQL문 결정
		String sql = "update board set titel = ?, set content = ? where m_id = ?"; // 물음표에 따옴표x
		// String이라 ""가 필요하고 그냥 "변수"이면 변수명이 그대로 입력되므로 변수명 양쪽에 " + 변수명 + " 을 해줌
		// java개발자들은 sql사용시 "이 아닌 '를 사용함. 스트링 사용시 잘못 인식할 수 있으므로
		// sql문 안에는 ;을 쓰지 않음.

		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, dto.getTitle()); 
		ps.setString(2, dto.getContent()); 
		ps.setString(3, dto.getM_id());

		// 메소드 prepareStatement을 사용해서 SQL문을 변수 ps로 가져옴
		System.out.println("3. SQL문 결정 성공...");

		// 4. SQL문 전송 요청
		ps.executeUpdate();
		System.out.println("4. SQL문 전송 요청 성공...");
		
		ps.close();
		con.close();
	}

//delete
	public void delete(BoardDTO dto) throws Exception {
		// 1. connector(driver) 설정
		Class.forName("com.mysql.jdbc.Driver");
		// 외부파일 처리시 //try catch 사용시 try이 안에 들어가야 함

		System.out.println("1. connector설정 설공...");

		// 디비버에서 정보를 보고 밑에 세개 입력 //접근권한이 있어야 연결되게 하려고
		String url = "jdbc:mysql://localhost:3306/board";
		String user = "root";
		String password = "1234";

		// 2. DB연결
		Connection con = DriverManager.getConnection(url, user, password); // 오버로딩 중 3개짜리 선택
		System.out.println("2. db연결 성공...");

		// 3. SQL문 결정

		String sql = "delete from board where m_id = ?"; // 물음표에 따옴표x
		// String이라 ""가 필요하고 그냥 "변수"이면 변수명이 그대로 입력되므로 변수명 양쪽에 " + 변수명 + " 을 해줌
		// java개발자들은 sql사용시 "이 아닌 '를 사용함. 스트링 사용시 잘못 인식할 수 있으므로
		// sql문 안에는 ;을 쓰지 않음.

		PreparedStatement ps = con.prepareStatement(sql);
//		ps.setInt(1, dto.getB_id());
		ps.setString(1, dto.getM_id()); 
//		ps.setString(3, dto.getTitle()); 
//		ps.setString(4, dto.getContent()); 
//		ps.setTimestamp(5, dto.getuDate());
//		ps.setInt(6, dto.getHits());

		// 메소드 prepareStatement을 사용해서 SQL문을 변수 ps로 가져옴
		System.out.println("3. SQL문 결정 성공...");

		// 4. SQL문 전송 요청
		ps.executeUpdate();
		System.out.println("4. SQL문 전송 요청 성공...");

		ps.close();
		con.close();
		
	}

//insert
	public void insert(BoardDTO dto) throws Exception {

		// 1. connector(driver) 설정
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. connector설정 설공...");

		String url = "jdbc:mysql://localhost:3306/board";
		String user = "root";
		String password = "1234";

		// 2. DB연결
		Connection con = DriverManager.getConnection(url, user, password); // 오버로딩 중 3개짜리 선택
		System.out.println("2. db연결 성공...");

		String sql = "insert into board (m_id, title, content, uDate, hits) values (?,?,?,now(),0)"; // 물음표에 따옴표x

		PreparedStatement ps = con.prepareStatement(sql); //sql문을 변수 ps로 불러오기
		ps.setString(1, dto.getM_id()); //나중에 member테이블에서 받아와야함.
		ps.setString(2, dto.getTitle()); 
		ps.setString(3, dto.getContent());

		System.out.println("3. SQL문 결정 성공...");

		// 4. SQL문 전송 요청
		ps.executeUpdate();
		System.out.println("4. SQL문 전송 요청 성공...");

		ps.close();
		con.close();

	}

	
// select문(검색용)
	public ArrayList<BoardDTO> selectS(BoardDTO dto) throws Exception { // 예외처리
		ArrayList<BoardDTO> list = new ArrayList();
		
		// 1. 드라이버 설정
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. 드라이버 설정 ok...");

		// 2. DB연결
		// url, user, password
		String url = "jdbc:mysql://localhost:3306/board";
		String user = "root";
		String password = "1234";

		Connection con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB연결 ok...");

		// 3. SQL문 결정
		String sql = "select b_id, title, m_id, uDate, hits from board where m_id like concat('%',?,'%')";
		//유사한 아이디 검색. = ? , 대신 like concat 사용
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, dto.getM_id());
		System.out.println("3. SQL문 객체화 ok...");

		// 4. SQL문 실행 요청
//			ps.executeUpdate(); //c, u, d 에만 사용!
		ResultSet rs = ps.executeQuery();

		while (rs.next()) {
			dto = new BoardDTO();
			int b_id = rs.getInt(1);
			String title = rs.getString(2);
			String m_id = rs.getString(3);
			Timestamp uDate = rs.getTimestamp(4);
			int hits = rs.getInt(5);
//			String content = rs.getString(3);

			dto.setB_id(b_id);
			dto.setTitle(title);
			dto.setM_id(m_id);
			dto.setuDate(uDate);
			dto.setHits(hits);
			
			list.add(dto);

		}

		System.out.println("4. SQL문 실행 요청 OK...");
		
		rs.close();
		ps.close();
		con.close();
		
		return list; // dto로 묶어서 반환
		
		}
	
	
//select문 (전체리스트)
	public ArrayList<BoardDTO> selectAll() throws Exception { // 예외처리
		ArrayList<BoardDTO> list = new ArrayList();
		// 1. 드라이버 설정
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. 드라이버 설정 ok...");

		// 2. DB연결
		// url, user, password
		String url = "jdbc:mysql://localhost:3306/board";
		String user = "root";
		String password = "1234";

		Connection con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB연결 ok...");

		// 3. SQL문 결정
		String sql = "select b_id, title, m_id, uDate, hits from board";
		PreparedStatement ps = con.prepareStatement(sql);
		System.out.println("3. SQL문 객체화 ok...");

		// 4. SQL문 실행 요청
//			ps.executeUpdate(); //c, u, d 에만 사용!
		ResultSet rs = ps.executeQuery();

		while (rs.next()) {
			BoardDTO dto = new BoardDTO();
			int b_id = rs.getInt(1);
			String title = rs.getString(2);
			String m_id = rs.getString(3);
			Timestamp uDate = rs.getTimestamp(4);
			int hits = rs.getInt(5);

			dto.setB_id(b_id);
			dto.setTitle(title);
			dto.setM_id(m_id);
			dto.setuDate(uDate);
			dto.setHits(hits);
			

			list.add(dto);
		}

		System.out.println("4. SQL문 실행 요청 OK...");

		rs.close();
		ps.close();
		con.close();
		
		return list; // dto로 묶어서 반환

	}
	
	// select문(contentView)
		public BoardDTO selectC(BoardDTO dto) throws Exception { // 예외처리
			// 1. 드라이버 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 드라이버 설정 ok...");

			// 2. DB연결
			// url, user, password
			String url = "jdbc:mysql://localhost:3306/board";
			String user = "root";
			String password = "1234";

			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ok...");

			// 3. SQL문 결정
			String sql = "select title, content from board where b_id = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, dto.getB_id());
			System.out.println("3. SQL문 객체화 ok...");

			// 4. SQL문 실행 요청
			//ps.executeUpdate(); //c, u, d 에만 사용!
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				String title = rs.getString(1);
				String content = rs.getString(2);

				dto.setTitle(title);
				dto.setContent(content);

			}

			rs.close();
			ps.close();
			con.close();
			
			return dto;
			
		}
		
		
		
}
