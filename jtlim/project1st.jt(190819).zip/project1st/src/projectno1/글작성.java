package projectno1;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class 글작성 {
	private JTextField t1;
	private JTextField t2;

	public 글작성(int x, int y) {
		
		JFrame f = new JFrame();
		f.setTitle("글작성");
		f.setSize(1200, 600);
		
		JPanel panel = new JPanel();
		f.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton b_l1 = new JButton("로그인");
		b_l1.setBounds(854, 10, 105, 32);
		panel.add(b_l1);
		
		JButton b_l2 = new JButton("회원가입");
		b_l2.setBounds(971, 10, 105, 32);
		panel.add(b_l2);
		
		JLabel lblNewLabel = new JLabel("제목");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 18));
		lblNewLabel.setBounds(130, 110, 57, 32);
		panel.add(lblNewLabel);
		
		t1 = new JTextField();
		t1.setBounds(205, 110, 871, 32);
		panel.add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		t2.setBounds(205, 152, 871, 265);
		panel.add(t2);
		t2.setColumns(10);
		
		JLabel label = new JLabel("내용");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("굴림", Font.PLAIN, 18));
		label.setBounds(130, 153, 57, 32);
		panel.add(label);
		
		JButton b_w = new JButton("글작성");
		b_w.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
		int data = JOptionPane.showConfirmDialog
		(null, "글작성을 완료하시겠습니까?", "글작성 확인창", JOptionPane.OK_CANCEL_OPTION);
			if (data == 0) {
				
				String m_id = JOptionPane.showInputDialog("id");
				String title = t1.getText();
				String content = t2.getText();
				
				BoardDTO dto = new BoardDTO();
				
				try {
					
					BoardDAO dao = new BoardDAO();
					dto.setM_id(m_id);
					dto.setTitle(title);
					dto.setContent(content);
					dao.insert(dto);
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
				
				
				try {
					목록 name = new 목록(f.getLocation().x,f.getLocation().y);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				f.dispose();
				
			}

				
				
			}
		});
		b_w.setBounds(862, 462, 97, 23);
		panel.add(b_w);
		
		JButton b_t = new JButton("목록가기");
		b_t.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					목록 name = new 목록(f.getLocation().x,f.getLocation().y);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				f.dispose();
				
			}
		});
		b_t.setBounds(979, 462, 97, 23);
		panel.add(b_t);
		
		f.setLocation(x, y);
		f.setVisible(true);
		
		
	}

}
