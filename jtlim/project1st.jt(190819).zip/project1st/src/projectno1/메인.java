package projectno1;

public class 메인 {

	public static void main(String[] args) {
		
		try {
			목록 name = new 목록(200, 150);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
