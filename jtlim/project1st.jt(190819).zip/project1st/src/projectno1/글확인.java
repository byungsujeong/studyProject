package projectno1;

import java.awt.BorderLayout;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class 글확인 {
	private JTextField t1;
	private JTextField t2;

	public 글확인(int x, int y, int z) {
		
		JFrame f = new JFrame();
		f.setTitle("글확인");
		f.setSize(1200, 600);
		
		JPanel panel = new JPanel();
		f.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton b_l1 = new JButton("로그인");
		b_l1.setBounds(854, 10, 105, 32);
		panel.add(b_l1);
		
		JButton b_l2 = new JButton("회원가입");
		b_l2.setBounds(971, 10, 105, 32);
		panel.add(b_l2);
		
		JLabel lblNewLabel = new JLabel("제목");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 18));
		lblNewLabel.setBounds(130, 110, 57, 32);
		panel.add(lblNewLabel);
		
		t1 = new JTextField();
		t1.setBounds(205, 110, 871, 32);
		panel.add(t1);
		t1.setColumns(10);
		
		
		JLabel label = new JLabel("내용");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("굴림", Font.PLAIN, 18));
		label.setBounds(130, 153, 57, 32);
		panel.add(label);

		t2 = new JTextField();
		t2.setHorizontalAlignment(SwingConstants.LEFT);
		t2.setBounds(205, 152, 871, 265);
		panel.add(t2);
		t2.setColumns(10);
		
		BoardDAO dao = new BoardDAO();
		BoardDTO dto = new BoardDTO();
		dto.setB_id(z);
		try {
			dao.selectC(dto);
		} catch (Exception e3) {
			e3.printStackTrace();
		}
		
		t1.setText(dto.getTitle());
		t2.setText(dto.getContent());
		
		JButton b_w = new JButton("글수정");
		b_w.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int data = JOptionPane.showConfirmDialog
				(null, "글수정을 완료하시겠습니까?", "글수정 확인창", JOptionPane.OK_CANCEL_OPTION);
				if (data == 0) {
					String m_id = JOptionPane.showInputDialog("id");
					
					BoardDTO dto = new BoardDTO();
					if (dto.getM_id().equals(m_id)) {
																						
						BoardDAO dao = new BoardDAO();
//						dto.setM_id(m_id);
						t1.setText(dto.getTitle());
						t1.setText(dto.getContent());
//						
						try {
							dao.update(dto);
						} catch (Exception e2) {
							e2.printStackTrace();
						}
						
					
					
					
					try {
						목록 name = new 목록(f.getLocation().x,f.getLocation().y);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					f.dispose();
					}
				}
			}
		});
		b_w.setBounds(741, 462, 97, 23);
		panel.add(b_w);
		
		JButton b_d = new JButton("글삭제");
		b_d.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int data = JOptionPane.showConfirmDialog
				(null, "글삭제를 완료하시겠습니까?", "글삭제 확인창", JOptionPane.OK_CANCEL_OPTION);
				if (data == 0) {
					
					String m_id = JOptionPane.showInputDialog("id");
//					String title = t1.getText();
//					String content = t2.getText();
					
					BoardDTO dto = new BoardDTO();
					BoardDAO dao = new BoardDAO();
					if (dto.getM_id().equals(m_id)) {
				
					
					try {
						dao.delete(dto);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					}
					
					try {
						목록 name = new 목록(f.getLocation().x,f.getLocation().y);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					f.dispose();
				}
				
			}
		});
		b_d.setBounds(862, 462, 97, 23);
		panel.add(b_d);
		
		
//		JButton b_d = new JButton("글삭제");
//		b_d.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
////				글작성확인창 name = new 글작성확인창();
//				
//			}
//		});
//		b_d.setBounds(862, 462, 97, 23);
//		panel.add(b_w);
				
		JButton b_t = new JButton("목록가기");
		b_t.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					목록 name = new 목록(f.getLocation().x,f.getLocation().y);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				f.dispose();
			}
		});
		b_t.setBounds(979, 462, 97, 23);
		panel.add(b_t);
		
		f.setLocation(x, y);
		f.setVisible(true);
		
			
		}

	public 글확인(int x, int y) {
		// TODO Auto-generated constructor stub
	}
	
	
}
