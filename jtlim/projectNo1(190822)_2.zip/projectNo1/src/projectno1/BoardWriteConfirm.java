package projectno1;

import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class BoardWriteConfirm {

	public BoardWriteConfirm() {
		
	//프레임 불러오기	
		JFrame f = new JFrame();
		f.setTitle("글작성확인창");
		f.setSize(300, 200);
		f.getContentPane().setLayout(null);
	
	//라벨 불러오기	
		JLabel lblNewLabel = new JLabel("글작성을 완료하시겠습니까?");
		lblNewLabel.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblNewLabel.setBounds(33, 46, 221, 15);
		f.getContentPane().add(lblNewLabel);
	
	//버튼(예) 불러오기	
		JButton b1 = new JButton("예");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		b1.setBounds(26, 99, 97, 23);
		f.getContentPane().add(b1);
		
	//버튼(아니요) 불러오기	
		JButton b2 = new JButton("아니요");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		b2.setBounds(157, 99, 97, 23);
		f.getContentPane().add(b2);
			

		f.setLocation(650, 350);
		f.setVisible(true);
		
		
	}
}
