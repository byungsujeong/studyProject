package projectno1;

public class Main {

	public static void main(String[] args) {
		
		try {
			BoardMain name = new BoardMain(200, 150);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
