package projectno1;

import java.sql.Timestamp;

public class Board {

	int b_id;
	String m_id;
	String title;
	String content;
	Timestamp uDate;
	int hits;
	
	public Board() {
		
	}

	public Board(int b_id, String m_id, String title, String content, Timestamp uDate, int hits) {
		super();
		b_id = b_id;
		m_id = m_id;
		this.title = title;
		this.content = content;
		this.uDate = uDate;
		this.hits = hits;
	}
	
	
	
}
