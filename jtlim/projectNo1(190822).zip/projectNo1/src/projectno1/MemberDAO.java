package projectno1;

import java.sql.*;
import java.util.ArrayList;

import javax.print.DocFlavor.STRING;
import javax.swing.JOptionPane;


public class MemberDAO {

//private static final MemberDTO mdto = null;

//insert
	public void insert(MemberDTO dto) throws Exception {

		// 1. connector(driver) 설정
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. connector설정 설공...");

		String url = "jdbc:mysql://localhost:3306/board";
		String user = "root";
		String password = "1234";

		// 2. DB연결
		Connection con = DriverManager.getConnection(url, user, password); // 오버로딩 중 3개짜리 선택
		System.out.println("2. db연결 성공...");

		String sql = "insert into board (m_id, pw, m_name, gender, birth, tall, tel, email) values (?,?,?,?,?,?,?,?,)"; // 물음표에 따옴표x

		PreparedStatement ps = con.prepareStatement(sql); //sql문을 변수 ps로 불러오기
		ps.setString(1, dto.getM_id()); //나중에 member테이블에서 받아와야함.
		ps.setString(2, dto.getPw()); 
		ps.setString(3, dto.getM_name());
		ps.setString(4, dto.getGender());
		ps.setString(5, dto.getBirth());
		ps.setInt(6, dto.getTall());
		ps.setString(7, dto.getTel());
		ps.setString(8, dto.getEmail());

		System.out.println("3. SQL문 결정 성공...");

		// 4. SQL문 전송 요청
		ps.executeUpdate();
		System.out.println("4. SQL문 전송 요청 성공...");

		ps.close();
		con.close();

	}

	
// select문(검색용)
	public ArrayList<BoardDTO> selectS(BoardDTO dto) throws Exception { // 예외처리
		ArrayList<BoardDTO> list = new ArrayList();
		
		// 1. 드라이버 설정
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. 드라이버 설정 ok...");

		// 2. DB연결
		// url, user, password
		String url = "jdbc:mysql://localhost:3306/board";
		String user = "root";
		String password = "1234";

		Connection con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB연결 ok...");

		// 3. SQL문 결정
		String sql = "select b_id, title, m_id, uDate, hits from board where m_id like concat('%',?,'%')";
		//유사한 아이디 검색. = ? , 대신 like concat 사용
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, dto.getM_id());
		System.out.println("3. SQL문 객체화 ok...");

		// 4. SQL문 실행 요청
//			ps.executeUpdate(); //c, u, d 에만 사용!
		ResultSet rs = ps.executeQuery();

		while (rs.next()) {
			dto = new BoardDTO();
			int b_id = rs.getInt(1);
			String title = rs.getString(2);
			String m_id = rs.getString(3);
			Timestamp uDate = rs.getTimestamp(4);
			int hits = rs.getInt(5);
//			String content = rs.getString(3);

			dto.setB_id(b_id);
			dto.setTitle(title);
			dto.setM_id(m_id);
			dto.setuDate(uDate);
			dto.setHits(hits);
			
			list.add(dto);

		}

		System.out.println("4. SQL문 실행 요청 OK...");
		
		rs.close();
		ps.close();
		con.close();
		
		return list; // dto로 묶어서 반환
		
		}
	
	
//select문 (전체리스트)
	public ArrayList<BoardDTO> selectAll() throws Exception { // 예외처리
		ArrayList<BoardDTO> list = new ArrayList();
		// 1. 드라이버 설정
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. 드라이버 설정 ok...");

		// 2. DB연결
		// url, user, password
		String url = "jdbc:mysql://localhost:3306/board";
		String user = "root";
		String password = "1234";

		Connection con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB연결 ok...");

		// 3. SQL문 결정
		String sql = "select b_id, title, m_id, uDate, hits from board";
		PreparedStatement ps = con.prepareStatement(sql);
		System.out.println("3. SQL문 객체화 ok...");

		// 4. SQL문 실행 요청
//			ps.executeUpdate(); //c, u, d 에만 사용!
		ResultSet rs = ps.executeQuery();

		while (rs.next()) {
			BoardDTO dto = new BoardDTO();
			int b_id = rs.getInt(1);
			String title = rs.getString(2);
			String m_id = rs.getString(3);
			Timestamp uDate = rs.getTimestamp(4);
			int hits = rs.getInt(5);

			dto.setB_id(b_id);
			dto.setTitle(title);
			dto.setM_id(m_id);
			dto.setuDate(uDate);
			dto.setHits(hits);
			

			list.add(dto);
		}

		System.out.println("4. SQL문 실행 요청 OK...");

		rs.close();
		ps.close();
		con.close();
		
		return list; // dto로 묶어서 반환

	}
	
	// select문(m_id가져오기)
		public MemberDTO selectId(MemberDTO mdto) throws Exception { // 예외처리
			// 1. 드라이버 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 드라이버 설정 ok...");

			// 2. DB연결
			// url, user, password
			String url = "jdbc:mysql://localhost:3306/board";
			String user = "root";
			String password = "1234";

			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. DB연결 ok...");

			// 3. SQL문 결정
			String sql = "select m_id from members where m_id = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, mdto.getM_id());
			System.out.println("3. SQL문 객체화 ok...");

			// 4. SQL문 실행 요청
			//ps.executeUpdate(); //c, u, d 에만 사용!
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				String m_id = rs.getString(1);

						mdto.setM_id(m_id);
				

			}

			rs.close();
			ps.close();
			con.close();
			
			return mdto;
			
		}
		
		
		
}
