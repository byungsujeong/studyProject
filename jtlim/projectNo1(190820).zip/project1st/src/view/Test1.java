package view;

import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JPanel;
import java.awt.GridLayout;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.BorderLayout;
import javax.swing.SwingConstants;
import javax.swing.BoxLayout;

public class Test1 {

	public static void main(String[] args) {
		
		String[] items = {"순차", "제목", "작성자", "작성일", "조회수"};
		Object[][] data = {
				{"5", "마", "e", "2019-08-16", "5"},
				{"4", "라", "d", "2019-08-15", "4"},
				{"3", "다", "c", "2019-08-14", "3"},
				{"2", "나", "b", "2019-08-13", "2"},
				{"1", "가", "a", "2019-08-12", "1"}
		};
		
		JFrame f = new JFrame();
		f.getContentPane().setFont(new Font("굴림", Font.PLAIN, 18));
		f.setTitle("게시판");
		f.setSize(1200, 600);
		f.getContentPane().setLayout(new BoxLayout(f.getContentPane(), BoxLayout.X_AXIS));
		
		JLabel title = new JLabel("게시판");
		title.setHorizontalAlignment(SwingConstants.CENTER);
		title.setFont(new Font("굴림", Font.PLAIN, 50));
		f.getContentPane().add(title);
//		f.getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JTable table = new JTable(data, items);
		f.getContentPane().add(table);
		
		JScrollPane scroll = new JScrollPane(table);
		f.getContentPane().add(scroll);
		
		f.setVisible(true);
		

	}

}
