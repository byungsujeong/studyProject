package view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTabbedPane;
import java.awt.ScrollPane;
import java.awt.Font;

public class Test2 {
	private static JTextField textField;

	public static void main(String[] args) {
		String[] items = {"순차", "제목", "작성자", "작성일", "조회수"};
		Object[][] data = {
				{"5", "마", "e", "2019-08-16", "5"},
				{"4", "라", "d", "2019-08-15", "4"},
				{"3", "다", "c", "2019-08-14", "3"},
				{"2", "나", "b", "2019-08-13", "2"},
				{"1", "가", "a", "2019-08-12", "1"}
		};
		
		JFrame f = new JFrame();
		f.setSize(1200, 600);
		
		JPanel panel = new JPanel();
		f.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JTable table = new JTable(data, items);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(110, 66, 961, 354);
		panel.add(scrollPane);
		
		
		JLabel lblNewLabel = new JLabel("Page");
		lblNewLabel.setBounds(375, 447, 57, 15);
		panel.add(lblNewLabel);
		
		JButton b_p1 = new JButton("1");
		b_p1.setFont(new Font("굴림", Font.PLAIN, 7));
		b_p1.setBounds(444, 443, 39, 23);
		panel.add(b_p1);
		
		JButton b_p2 = new JButton("2");
		b_p2.setFont(new Font("굴림", Font.PLAIN, 7));
		b_p2.setBounds(484, 443, 39, 23);
		panel.add(b_p2);
		
		JButton b_p3 = new JButton("3");
		b_p3.setFont(new Font("굴림", Font.PLAIN, 7));
		b_p3.setBounds(523, 443, 39, 23);
		panel.add(b_p3);
		
		JButton b_p4 = new JButton("4");
		b_p4.setFont(new Font("굴림", Font.PLAIN, 7));
		b_p4.setBounds(562, 443, 39, 23);
		panel.add(b_p4);
		
		JButton b_p5 = new JButton("5");
		b_p5.setFont(new Font("굴림", Font.PLAIN, 7));
		b_p5.setBounds(603, 443, 39, 23);
		panel.add(b_p5);
		
		JButton b_l1 = new JButton("로그인");
		b_l1.setBounds(854, 10, 105, 32);
		panel.add(b_l1);
		
		JButton b_l2 = new JButton("회원가입");
		b_l2.setBounds(971, 10, 105, 32);
		panel.add(b_l2);
		
		JLabel lblNewLabel_1 = new JLabel("검색");
		lblNewLabel_1.setBounds(375, 487, 57, 15);
		panel.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(444, 484, 245, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		JButton b_d = new JButton("돋보기");
		b_d.setFont(new Font("굴림", Font.PLAIN, 10));
		b_d.setBounds(701, 483, 69, 23);
		panel.add(b_d);
		
		JButton b_w = new JButton("글작성");
		b_w.setBounds(862, 483, 97, 23);
		panel.add(b_w);
		
		
		
		f.setVisible(true);
		

	}
}
